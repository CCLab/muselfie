import { Observable } from "data/observable";

export class HomeViewModel extends Observable {
    constructor() {
        super();
    }
}
