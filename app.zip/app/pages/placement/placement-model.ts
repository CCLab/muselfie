import { Observable } from "data/observable";
import { screen } from "platform";
import * as bitmapFactory from "nativescript-bitmap-factory";
import { Size } from "ui/core/view";
import {layout} from "tns-core-modules/utils/utils";
import {ImageAsset} from "tns-core-modules/image-asset";
import {ImageSource} from "tns-core-modules/image-source";

interface OvalDimensions {
    x: number;
    y: number;
    width: number;
    height: number;
    rotation: number;
}

interface PhotoScale {
    scale: number;
    xTranslation: number;
    yTranslation: number;
}

declare var android;

export class PlacementModel extends Observable {
    public chosenPhotoPath = "";
    public chosenBackgroundPath = "";

    public finalImageSource: ImageSource;
    public faceDimensions: OvalDimensions;
    public placementDimensions: OvalDimensions;

    public placementX: number;
    public placementY: number;
    public placementWidth: number;
    public placementHeight: number;
    public placementRotation: number;
  
    private commitedPlacementWidth: number;
    private commitedPlacementHeight: number;
    private commitedPlacementX: number;
    private commitedPlacementY: number;
    private commitedPlacementRotation: number;
  
    
    constructor() {
        super();
        this.placementWidth = screen.mainScreen.widthDIPs * 0.4;
        this.placementHeight = screen.mainScreen.widthDIPs * 0.6;
        this.commitedPlacementWidth = this.placementWidth;
        this.commitedPlacementHeight = this.placementHeight;
        this.placementX = screen.mainScreen.widthDIPs * 0.3;
        this.placementY = screen.mainScreen.heightDIPs * 0.3 - (this.placementHeight / 2);
        this.commitedPlacementX = this.placementX;
        this.commitedPlacementY = this.placementY;
        this.commitedPlacementRotation = 0;
        this.placementRotation = this.commitedPlacementRotation;
    }

    
    public createBackground(imageSize: Size){
        const photo = new ImageAsset(this.chosenPhotoPath);
        const imageWidthPx = layout.toDevicePixels(imageSize.width);
        const imageHeightPx = layout.toDevicePixels(imageSize.height);

        // The bitmap
        let bmp = bitmapFactory.create(imageWidthPx, imageHeightPx);

        bmp.dispose(() => {
            // Main canvas
            const canvas = (bmp as any).__canvas;
            const paint = new android.graphics.Paint();
            paint.setFilterBitmap(true);
            paint.setDither(true);
            paint.setAntiAlias(true);

            // Add the face

            // What part of the photo to use?
            const photoScale = PlacementModel.aspectFillSettings(
                photo,
                imageWidthPx,
                imageHeightPx,
            );

            let faceTopLeft = PlacementModel.fromScaledToOriginalCoordinates(
                photoScale,
                this.faceDimensions.x,
                this.faceDimensions.y,
            );
            let faceBottomRight = PlacementModel.fromScaledToOriginalCoordinates(
                photoScale,
                this.faceDimensions.x + this.faceDimensions.width,
                this.faceDimensions.y + this.faceDimensions.height,
            );
            let sourceRect = new android.graphics.Rect(
                faceTopLeft.x,
                faceTopLeft.y,
                faceBottomRight.x,
                faceBottomRight.y,
            );
            const data = bmp.toDataUrl(bitmapFactory.OutputFormat.PNG);
            console.log(data);
    })}

    public static aspectFillSettings(bitmap, width: number, height: number): PhotoScale {
        let scale: number;
        let xTranslation = 0;
        let yTranslation = 0;
        const originalWidth = bitmap.getWidth();
        const originalHeight = bitmap.getHeight();
        const originalAspect = originalWidth / originalHeight;
        const newAspect = width / height;

        if (originalAspect > newAspect) {
            scale = height / originalHeight;
            xTranslation = (width - originalWidth * scale)/2;
        }
        else {
            scale = width / originalWidth;
            yTranslation = (height - originalHeight * scale)/2;
        }
        return {scale, xTranslation, yTranslation};
    }

    /**
     * Takes coordinates in the coordinate system of a scaled on-screen image (in dip) and returns
     * coordinates in the coordinate systems of the original image (in px).
     * photoScale is an object containing scaling settings returned by aspectFillSettings.
     */
    public static fromScaledToOriginalCoordinates(photoScale: PhotoScale, x, y) {
        let newX = (layout.toDevicePixels(x) - photoScale.xTranslation) / photoScale.scale;
        let newY = (layout.toDevicePixels(y) - photoScale.yTranslation) / photoScale.scale;
        return {x: newX, y: newY};
    }

    public movePlacementPosition(x: number, y: number) {
        this.set("placementX", this.commitedPlacementX + x);
        this.set("placementY", this.commitedPlacementY + y);
    }

    public scalePlacementSize(factor: number) {
        this.set("placementWidth", this.commitedPlacementWidth * factor);
        this.set("placementHeight", this.commitedPlacementHeight * factor);
    }

    public setPlacementPosition(x: number, y: number) {
        this.set("placementX", x);
        this.set("placementY", y);
    }

    public setPlacementRotation(deg: number){
        this.set("placementRotation", this.commitedPlacementRotation + deg);
    }
  
    public commitPlacementChanges() {
        this.set("commitedPlacementWidth", this.placementWidth);
        this.set("commitedPlacementHeight", this.placementHeight);
        this.set("commitedPlacementX", this.placementX);
        this.set("commitedPlacementY", this.placementY); 
        this.set("commitedPlacementRotation", this.placementRotation);    
    }
}
