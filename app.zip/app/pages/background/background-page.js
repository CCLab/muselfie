"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var frameModule = require("tns-core-modules/ui/frame");
var imagepicker = require("nativescript-imagepicker");
var imageSource = require("image-source");
var fs = require("file-system");
var app = require("application");
var fresco = require("nativescript-fresco");
var background_model_1 = require("./background-model");
function onNavigatingTo(args) {
    var page = args.object;
    if (!page.bindingContext) {
        page.bindingContext = new background_model_1.BackgroundModel();
    }
    page.bindingContext.set("chosenBackgroundPath", page.navigationContext.chosenBackgroundPath);
}
exports.onNavigatingTo = onNavigatingTo;
function backTap(args) {
    frameModule.topmost().goBack();
}
exports.backTap = backTap;
function choosePhoto(args) {
    var button = args.object;
    var page = button.page;
    var context = imagepicker.create({
        mode: "single",
    });
    context
        .authorize()
        .then(function () {
        return context.present();
    })
        .then(function (selection) {
        selection.forEach(function (selected) {
            imageSource.fromAsset(selected).then(function (image) {
                var folder = fs.knownFolders.temp();
                var fileName = "_chosen_image.jpg";
                var path = fs.path.join(folder.path, fileName);
                image.saveToFile(path, "jpg");
                fresco.getImagePipeline().evictFromCache("file:" + path);
                page.bindingContext.set("chosenPhotoPath", path);
                // clear background-image cache (for the Label on the next screen)
                var context = app.android.context;
                var fetcher = org.nativescript.widgets.image.Fetcher.getInstance(context);
                fetcher.clearCache();
                frameModule.topmost().navigate({
                    moduleName: "pages/face/face-page",
                    transition: { name: "slide" },
                    context: {
                        chosenPhotoPath: page.bindingContext.chosenPhotoPath,
                        chosenBackgroundPath: page.bindingContext.chosenBackgroundPath,
                    },
                });
            }).catch(function (reason) {
                console.error(reason);
            });
        });
    });
}
exports.choosePhoto = choosePhoto;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC1wYWdlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYmFja2dyb3VuZC1wYWdlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsdURBQXlEO0FBS3pELHNEQUF3RDtBQUN4RCwwQ0FBNEM7QUFDNUMsZ0NBQWtDO0FBQ2xDLGlDQUFtQztBQUNuQyw0Q0FBOEM7QUFDOUMsdURBQXFEO0FBRXJELHdCQUErQixJQUFtQjtJQUM5QyxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsTUFBYyxDQUFDO0lBRWpDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLGtDQUFlLEVBQUUsQ0FBQztJQUNoRCxDQUFDO0lBRUQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLG9CQUFvQixDQUFDLENBQUM7QUFDN0YsQ0FBQztBQVJMLHdDQVFLO0FBRUwsaUJBQXdCLElBQW1CO0lBQ3ZDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztBQUNuQyxDQUFDO0FBRkQsMEJBRUM7QUFJRCxxQkFBNEIsSUFBZTtJQUN2QyxJQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBYyxDQUFDO0lBQ25DLElBQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFZLENBQUM7SUFDakMsSUFBSSxPQUFPLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQztRQUM3QixJQUFJLEVBQUUsUUFBUTtLQUNqQixDQUFDLENBQUM7SUFDSCxPQUFPO1NBQ04sU0FBUyxFQUFFO1NBQ1gsSUFBSSxDQUFDO1FBQ0YsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUM3QixDQUFDLENBQUM7U0FDRCxJQUFJLENBQUMsVUFBQyxTQUFTO1FBQ1osU0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFDLFFBQVE7WUFDdkIsV0FBVyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxLQUFLO2dCQUN2QyxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNwQyxJQUFJLFFBQVEsR0FBRyxtQkFBbUIsQ0FBQztnQkFDbkMsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFFL0MsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQzlCLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGNBQWMsQ0FBQyxVQUFRLElBQU0sQ0FBQyxDQUFDO2dCQUN6RCxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFFakQsa0VBQWtFO2dCQUNsRSxJQUFJLE9BQU8sR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztnQkFDbEMsSUFBSSxPQUFPLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQzFFLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDckIsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFDLFFBQVEsQ0FBQztvQkFDM0IsVUFBVSxFQUFFLHNCQUFzQjtvQkFDbEMsVUFBVSxFQUFFLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRTtvQkFDN0IsT0FBTyxFQUFFO3dCQUNMLGVBQWUsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLGVBQWU7d0JBQ3BELG9CQUFvQixFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CO3FCQUNqRTtpQkFDSixDQUFDLENBQUM7WUFDUCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBQyxNQUFNO2dCQUNaLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDMUIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQztBQXZDRCxrQ0F1Q0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBmcmFtZU1vZHVsZSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91aS9mcmFtZVwiO1xuaW1wb3J0IHsgTmF2aWdhdGVkRGF0YSwgUGFnZSB9IGZyb20gXCJ1aS9wYWdlXCI7XG5pbXBvcnQgeyBWaWV3IH0gZnJvbSBcInVpL2NvcmUvdmlld1wiO1xuaW1wb3J0IHsgRXZlbnREYXRhIH0gZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvZGF0YS9vYnNlcnZhYmxlXCI7XG5cbmltcG9ydCAqIGFzIGltYWdlcGlja2VyIGZyb20gXCJuYXRpdmVzY3JpcHQtaW1hZ2VwaWNrZXJcIjtcbmltcG9ydCAqIGFzIGltYWdlU291cmNlIGZyb20gXCJpbWFnZS1zb3VyY2VcIjtcbmltcG9ydCAqIGFzIGZzIGZyb20gXCJmaWxlLXN5c3RlbVwiO1xuaW1wb3J0ICogYXMgYXBwIGZyb20gXCJhcHBsaWNhdGlvblwiO1xuaW1wb3J0ICogYXMgZnJlc2NvIGZyb20gXCJuYXRpdmVzY3JpcHQtZnJlc2NvXCI7XG5pbXBvcnQgeyBCYWNrZ3JvdW5kTW9kZWwgfSBmcm9tIFwiLi9iYWNrZ3JvdW5kLW1vZGVsXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBvbk5hdmlnYXRpbmdUbyhhcmdzOiBOYXZpZ2F0ZWREYXRhKSB7XG4gICAgY29uc3QgcGFnZSA9IGFyZ3Mub2JqZWN0IGFzIFBhZ2U7XG5cbiAgICBpZiAoIXBhZ2UuYmluZGluZ0NvbnRleHQpIHtcbiAgICAgICAgcGFnZS5iaW5kaW5nQ29udGV4dCA9IG5ldyBCYWNrZ3JvdW5kTW9kZWwoKTtcbiAgICB9XG5cbiAgICBwYWdlLmJpbmRpbmdDb250ZXh0LnNldChcImNob3NlbkJhY2tncm91bmRQYXRoXCIsIHBhZ2UubmF2aWdhdGlvbkNvbnRleHQuY2hvc2VuQmFja2dyb3VuZFBhdGgpO1xuICAgIH1cblxuZXhwb3J0IGZ1bmN0aW9uIGJhY2tUYXAoYXJnczogTmF2aWdhdGVkRGF0YSkge1xuICAgIGZyYW1lTW9kdWxlLnRvcG1vc3QoKS5nb0JhY2soKTtcbn1cblxuZGVjbGFyZSB2YXIgb3JnO1xuXG5leHBvcnQgZnVuY3Rpb24gY2hvb3NlUGhvdG8oYXJnczogRXZlbnREYXRhKSB7XG4gICAgY29uc3QgYnV0dG9uID0gYXJncy5vYmplY3QgYXMgVmlldztcbiAgICBjb25zdCBwYWdlID0gYnV0dG9uLnBhZ2UgYXMgUGFnZTtcbiAgICBsZXQgY29udGV4dCA9IGltYWdlcGlja2VyLmNyZWF0ZSh7XG4gICAgICAgIG1vZGU6IFwic2luZ2xlXCIsXG4gICAgfSk7XG4gICAgY29udGV4dFxuICAgIC5hdXRob3JpemUoKVxuICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgcmV0dXJuIGNvbnRleHQucHJlc2VudCgpO1xuICAgIH0pXG4gICAgLnRoZW4oKHNlbGVjdGlvbikgPT4ge1xuICAgICAgICBzZWxlY3Rpb24uZm9yRWFjaCgoc2VsZWN0ZWQpID0+IHtcbiAgICAgICAgICAgIGltYWdlU291cmNlLmZyb21Bc3NldChzZWxlY3RlZCkudGhlbigoaW1hZ2UpID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgZm9sZGVyID0gZnMua25vd25Gb2xkZXJzLnRlbXAoKTtcbiAgICAgICAgICAgICAgICBsZXQgZmlsZU5hbWUgPSBgX2Nob3Nlbl9pbWFnZS5qcGdgO1xuICAgICAgICAgICAgICAgIGxldCBwYXRoID0gZnMucGF0aC5qb2luKGZvbGRlci5wYXRoLCBmaWxlTmFtZSk7XG5cbiAgICAgICAgICAgICAgICBpbWFnZS5zYXZlVG9GaWxlKHBhdGgsIFwianBnXCIpO1xuICAgICAgICAgICAgICAgIGZyZXNjby5nZXRJbWFnZVBpcGVsaW5lKCkuZXZpY3RGcm9tQ2FjaGUoYGZpbGU6JHtwYXRofWApO1xuICAgICAgICAgICAgICAgIHBhZ2UuYmluZGluZ0NvbnRleHQuc2V0KFwiY2hvc2VuUGhvdG9QYXRoXCIsIHBhdGgpO1xuXG4gICAgICAgICAgICAgICAgLy8gY2xlYXIgYmFja2dyb3VuZC1pbWFnZSBjYWNoZSAoZm9yIHRoZSBMYWJlbCBvbiB0aGUgbmV4dCBzY3JlZW4pXG4gICAgICAgICAgICAgICAgbGV0IGNvbnRleHQgPSBhcHAuYW5kcm9pZC5jb250ZXh0O1xuICAgICAgICAgICAgICAgIGxldCBmZXRjaGVyID0gb3JnLm5hdGl2ZXNjcmlwdC53aWRnZXRzLmltYWdlLkZldGNoZXIuZ2V0SW5zdGFuY2UoY29udGV4dCk7XG4gICAgICAgICAgICAgICAgZmV0Y2hlci5jbGVhckNhY2hlKCk7XG4gICAgICAgICAgICAgICAgZnJhbWVNb2R1bGUudG9wbW9zdCgpLm5hdmlnYXRlKHtcbiAgICAgICAgICAgICAgICAgICAgbW9kdWxlTmFtZTogXCJwYWdlcy9mYWNlL2ZhY2UtcGFnZVwiLFxuICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiB7IG5hbWU6IFwic2xpZGVcIiB9LFxuICAgICAgICAgICAgICAgICAgICBjb250ZXh0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjaG9zZW5QaG90b1BhdGg6IHBhZ2UuYmluZGluZ0NvbnRleHQuY2hvc2VuUGhvdG9QYXRoLFxuICAgICAgICAgICAgICAgICAgICAgICAgY2hvc2VuQmFja2dyb3VuZFBhdGg6IHBhZ2UuYmluZGluZ0NvbnRleHQuY2hvc2VuQmFja2dyb3VuZFBhdGgsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KS5jYXRjaCgocmVhc29uKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihyZWFzb24pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH0pO1xufVxuIl19