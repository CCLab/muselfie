"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var observable_1 = require("data/observable");
var BackgroundModel = /** @class */ (function (_super) {
    __extends(BackgroundModel, _super);
    function BackgroundModel() {
        var _this = _super.call(this) || this;
        _this.chosenBackgroundPath = "";
        _this.chosenPhotoPath = "";
        return _this;
    }
    return BackgroundModel;
}(observable_1.Observable));
exports.BackgroundModel = BackgroundModel;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC1tb2RlbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImJhY2tncm91bmQtbW9kZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSw4Q0FBNkM7QUFHN0M7SUFBcUMsbUNBQVU7SUFJM0M7UUFBQSxZQUNJLGlCQUFPLFNBQ1Y7UUFMTSwwQkFBb0IsR0FBRyxFQUFFLENBQUM7UUFDMUIscUJBQWUsR0FBRyxFQUFFLENBQUM7O0lBSTVCLENBQUM7SUFDTCxzQkFBQztBQUFELENBQUMsQUFQRCxDQUFxQyx1QkFBVSxHQU85QztBQVBZLDBDQUFlIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gXCJkYXRhL29ic2VydmFibGVcIjtcbmltcG9ydCB7IEZpbGVTeXN0ZW1FbnRpdHkgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9maWxlLXN5c3RlbVwiO1xuXG5leHBvcnQgY2xhc3MgQmFja2dyb3VuZE1vZGVsIGV4dGVuZHMgT2JzZXJ2YWJsZSB7XG4gICAgcHVibGljIGNob3NlbkJhY2tncm91bmRQYXRoID0gXCJcIjtcbiAgICBwdWJsaWMgY2hvc2VuUGhvdG9QYXRoID0gXCJcIjtcblxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcigpO1xuICAgIH1cbn1cbiJdfQ==